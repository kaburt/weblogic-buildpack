#Copy over jars required to be loaded ahead of the weblogic server in its classpath into this folder
# Examples can be Server side patches, or other application related jars 
# that need to be loaded well ahead of the app bits or server 
